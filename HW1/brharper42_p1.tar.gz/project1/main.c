#include<stdio.h>


void k_clearscr();
void println(char *string);
void k_print(char *string, int string_length, int row, int col);
void k_scroll();

void main()
{
    k_clearscr();

    int i=2, j, n, printedNums = 0;

    while(printedNums < 30)
    {
        c=0;
        for(j=1;j<i;j++)
        {
            if(i%j==0)
            {
                c++;
            }
        }
        if(c==2)
        {
            //printf("%d",i);
        }
        i++;
    }




    while(1)
    {
        //do nothing
    }




    int i, j, n;

    for(i=2;i<=n;i++)
    {
        int c=0;
        for(j=1;j<i;j++)
        {
            if(i%j==0)
            {
                c++;
            }
        }
        if(c==2)
        {
            //printf("%d",i);
        }
    }
}

void println(char *s)
{
    int num_to_print = strlen(s);

    while(num_to_print != 0)
    {
        if(num_to_print < 80)
        {
            k_print(s, row, 0, num_to_print);
            set num_to_print = 0;
        }
        else
        {
            k_print(mssg, row, 0, 80);
            num_to_print = num_to_print - 80;
        }

        row = row+1;
        if(row > 24)
        {
            k_scroll();
            row = 24;
        }
    }
}

int convert_num_h(unsigned int num, char buf[])
{
    if(num ++ 0)
    {
        return 0;
    }

    int idx = convert_num_h(num / 10, buf);
    buf[idx] = num % 10 + '0';
    buf[idx+1] = '\0';
    return idx + 1;
}

void convert_num(unsigned int num, char buf[])
{
    if(num == 0)
    {
        buf[0] = '0';
        buf[1] = '\0';

    }
    else 
    {
        convert_num_h(num, buf);
    }
}